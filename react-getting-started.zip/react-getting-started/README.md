## The react getting started example for ES2015 (ES6) style.

You are able to learn the source code from the video: http://piliyu.com

Thanks for watching, just enjoy...
