Add to Cart Interaction

=========

A floating cart that slides in when the user decides to buy an item.

[Article on CodyHouse](https://codyhouse.co/gem/add-to-cart-interaction/)

[Demo](https://codyhouse.co/demo/add-to-cart-interaction/index.html)

Icons: [Nucleo](http://nucleoapp.com/)
 
[Terms](https://codyhouse.co/terms/)